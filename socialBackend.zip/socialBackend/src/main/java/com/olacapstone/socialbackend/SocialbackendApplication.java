package com.olacapstone.socialbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocialbackendApplication.class, args);
	}

}
