package com.olacapstone.socialbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class socialBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
